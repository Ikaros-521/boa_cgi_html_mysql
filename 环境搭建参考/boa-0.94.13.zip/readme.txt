BOA+CGIC，发现用它那个测试程序上传文件时只能传1MB大小左右，后来搜索网络，发现是BOA搞的鬼，方法2种：

1、修改源代码的defines.h里面的宏SINGLE_POST_LIMIT_DEFAULT

2、修改boa.conf里面的SinglePostLimit
